# -*- coding: utf-8 -*-
"""
Created on Mon Nov  7 23:55:38 2016

@author: Jiahao
"""
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
from sklearn import cross_validation
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score

from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.neighbors import KNeighborsClassifier

from sklearn import preprocessing
from sklearn.preprocessing import label_binarize
from sklearn.metrics import roc_curve, auc
from itertools import cycle

#########################################ROC###################################
#GET code from:
#http://scikit-learn.org/stable/auto_examples/model_selection/plot_roc.html#sphx-glr-auto-examples-model-selection-plot-roc-py
def ROC(y_score):
    y=Y_validate
    y = label_binarize(y, classes=[1,2,3,4,5])
    n_classes=y.shape[1]
    y_test=y
    
    # Compute ROC curve and ROC area for each class
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for i in range(n_classes):
        fpr[i], tpr[i], _ = roc_curve(y_test[:, i], y_score[:, i])
        roc_auc[i] = auc(fpr[i], tpr[i])
    
    plt.figure()
    lw = 2
    
    colors = cycle(['aqua', 'darkorange', 'cornflowerblue','green'])
    for i, color in zip(range(n_classes), colors):
        plt.plot(fpr[i], tpr[i], color=color, lw=lw,
                 label='ROC curve of class {0} (area = {1:0.2f})'
                 ''.format(i, roc_auc[i]))
    
    plt.plot([0, 1], [0, 1], 'k--', lw=lw)
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Receiver operating characteristic')
    plt.legend(loc="lower right")
    plt.show()
################################Mechaine Learning##############################
city_list=['Washington, DC','NYC','Chicago','San Francisco']
for myFileName in city_list:
    print(myFileName)
    df=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/'+myFileName+'_analysis.csv',sep=',',encoding='latin1')
    myData=df[['Driving_distance', 'there_is_deal', 'latitude','longitude']]
    #create dummpy variable for category
    food_type=df[['food_type']]
    food_type_dummy=pd.get_dummies(food_type, prefix=['Is_'])
    myData=pd.concat([myData,food_type_dummy],axis=1)
    #downround the rating such as 3.5->3,b/c upround make the data very unbalanced
    myData["rating"] = round(df["rating"]-0.1)
    
    
    # Look at the number of instances of each class
    # rating distribution
    print(myData.groupby('rating').size())
    
    ######################################################
    # Evaluate algorithms
    ######################################################
    
    # Separate training and final validation data set. First remove class
    # label from data (X). Setup target class (Y)
    # Then make the validation set 20% of the entire
    # set of labeled data (X_validate, Y_validate)
    valueArray = myData.values
    X = valueArray[:,0:13]
    Y = valueArray[:,13]
    test_size = 0.20
    seed = 7
    
    # normalize data
    X=np.float64(X)
    norm_X = preprocessing.normalize(X)
    Y=np.float64(Y)
    X_train, X_validate, Y_train, Y_validate = cross_validation.train_test_split(norm_X, Y, test_size=test_size, random_state=seed)
    
    # Setup 10-fold cross validation to estimate the accuracy of different models
    # Split data into 10 parts
    # Test options and evaluation metric
    num_folds = 10
    num_instances = len(X_train)
    seed = 7
    scoring = 'accuracy'
    
    ######################################################
    # Use different algorithms to build models
    ######################################################
    
    # Add each algorithm and its name to the model array
    models = []
    models.append(('DecisionTree', DecisionTreeClassifier()))
    models.append(('RandomForest', RandomForestClassifier()))
    models.append(('KNN', KNeighborsClassifier()))
    models.append(('NaiveBayes', GaussianNB()))
    models.append(('SVM', SVC()))
    
    
    # Evaluate each model, add results to a results array,
    # Print the accuracy results (remember these are averages and std
    
    results = []
    names = []
    for name, model in models:
        kfold = cross_validation.KFold(n=num_instances, n_folds=num_folds, random_state=seed)
        cv_results = cross_validation.cross_val_score(model, X_train, Y_train, cv=kfold, scoring=scoring)
        #print(cv_results)
        results.append(cv_results)
        names.append(name)
        msg = "%s: %f (%f)" % (name, cv_results.mean(), cv_results.std())
        print(msg)
    
    dt = DecisionTreeClassifier()
    dt.fit(X_train,Y_train)
    predictions1 = dt.predict(X_validate)
    print("Decision Tree")
    print(accuracy_score(Y_validate, predictions1))
    print(confusion_matrix(Y_validate, predictions1))    
    
    rf = RandomForestClassifier()
    rf.fit(X_train,Y_train)
    predictions2 = rf.predict(X_validate)
    print("Random Forest")
    print(accuracy_score(Y_validate, predictions2))
    print(confusion_matrix(Y_validate, predictions2))
    
    kn = KNeighborsClassifier()
    kn.fit(X_train,Y_train)
    predictions3 = rf.predict(X_validate)
    print("KNN")
    print(accuracy_score(Y_validate, predictions3))
    print(confusion_matrix(Y_validate, predictions3))
    
    nb = GaussianNB()
    nb.fit(X_train,Y_train)
    predictions4 = nb.predict(X_validate)
    print("Naive Bayes")
    print(accuracy_score(Y_validate, predictions4))
    print(confusion_matrix(Y_validate, predictions4))
        
    svm = SVC()
    svm.fit(X_train, Y_train)
    predictions5 = svm.predict(X_validate)
    print("Support Vector Machine")
    print(accuracy_score(Y_validate, predictions5))
    print(confusion_matrix(Y_validate, predictions5))
    y_score = svm.fit(X_train, Y_train).decision_function(X_validate)
    ROC(y_score=y_score)






