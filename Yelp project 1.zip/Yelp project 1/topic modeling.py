# -*- coding: utf-8 -*-
"""
Created on Sat Dec  3 00:31:47 2016

@author: Jiahao
"""
from __future__ import print_function
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.decomposition import  LatentDirichletAllocation
import pandas as pd
import numpy as np
from wordcloud import WordCloud
import matplotlib.pyplot as plt
import re
from scipy.stats import chi2_contingency

df=pd.DataFrame(columns=[' name','food_type','rating','city'])
city_list=['Washington, DC','NYC','Chicago','San Francisco']
for myFileName in city_list:
    print(myFileName)
    data=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/'+myFileName+'_analysis.csv',sep=',',encoding='latin1')
    city_data=data[[' name','food_type','rating','categories_list']]    
    city_data['city']=myFileName
    df=pd.concat([df,city_data])
#reset index
def reindex(df):    
    df['index']=np.arange(len(df))
    df=df.set_index('index')
    return(df)
    
df= reindex(df)
"""
LDA get topic     
Reference: http://scikit-learn.org/stable/auto_examples/applications/
topics_extraction_with_nmf_lda.html#sphx-glr-auto-examples-applications-
topics-extraction-with-nmf-lda-py
"""
n_topics = 3
n_top_words = 5
n_features = 1000

#save top words
def save_top_words(model, feature_names, n_top_words):
    top_words=[]
    top_words_weight=[]
    for topic_idx, topic in enumerate(model.components_):     
        top_words.append([feature_names[i]
                        for i in topic.argsort()[:-n_top_words - 1:-1]])
        top_words_weight.append([model.components_[topic_idx][i]
                                 for i in topic.argsort()[:-n_top_words - 1:-1]])
    #get the topic words
    words=pd.DataFrame(top_words)
    words=words.transpose()
    #get topic weights        
    weights=pd.DataFrame(top_words_weight)
    weights=weights.transpose()    
    #combine the words and their weight
    topic_info=pd.DataFrame()
    for i in range(n_topics):
        topic_info.loc[:,2*i-1]=words.ix[:,i]
        topic_info.loc[:,2*i]=weights.ix[:,i]/sum(weights.ix[:,i])
    print(topic_info)
    return(topic_info)


    
#set vectorizer
tf_vectorizer = CountVectorizer(max_df=0.95, min_df=2,max_features=n_features,
                                stop_words='english')
#set  Latent Dirichlet Allocation
lda = LatentDirichletAllocation(n_topics=n_topics, max_iter=5,
                                learning_method='online',
                                learning_offset=50.,
                                random_state=0)
#get data  
data=df.ix[:,0]
#vectorize data
tf = tf_vectorizer.fit_transform(data)
#fit the data
lda.fit(tf)
#get results
tf_feature_names = tf_vectorizer.get_feature_names()
top_words=save_top_words(lda, tf_feature_names,n_top_words)
#rename columns
top_words=top_words.rename(index=str, columns={-1: "topic_0", 0: "weight_0",1: "topic_1", 
                                     2: "weight_1", 3: "topic_2",4: "weight_2"})


#select restaurant name by different criteria such as food type or city or rating
def choose_sample_data(dataframe,criteria_type,criteria):
    test_data=dataframe.loc[df[criteria_type].isin(criteria)]
    sample=test_data.ix[:,0]
    sample_list=sample.tolist()
    return(sample_list)
"""
word count
"""
def wordcount(sample_list):
   #verctorizer
   vectorizer = CountVectorizer(min_df=1, ngram_range=(1,1),token_pattern=r'\b\w+\b')
   X = vectorizer.fit_transform(sample_list)
   #W=vectorizer.get_feature_names()
   #get an empty dataframe to store term , term count and topic
   Words_count=pd.DataFrame(columns=['term','count','weighted count','topic'])
   i=0
   for top_num in range(n_topics):
       for k in range(n_top_words):
           term=top_words.ix[k,2*top_num-2]
           weight=top_words.ix[k,2*top_num-1]
           count=0    
           col_num=vectorizer.vocabulary_.get(term)
           if col_num is None:
               continue
           else:
               for k in range(len(sample_list)):
                   count=count+X[k,col_num]
               Words_count.loc[i,'term']=term
               Words_count.loc[i,'count']=count
               Words_count.loc[i,'weighted count']=count*weight
               Words_count.loc[i,'topic']=top_num      
               i=i+1
   return(Words_count)

"""
Topic Analysis
"""
def find_percentage(sample_list):
    wc=wordcount(sample_list=sample_list)  
    tp_0=wc.loc[wc['topic'].isin([0])]
    count_0=sum(tp_0.ix[:,2])
    tp_1=wc.loc[wc['topic'].isin([1])]
    count_1=sum(tp_1.ix[:,2])
    tp_2=wc.loc[wc['topic'].isin([2])]
    count_2=sum(tp_2.ix[:,2])
    total_count=count_0+count_1+count_2
    percentage_0=count_0/total_count
    percentage_1=count_1/total_count
    percentage_2=count_2/total_count
    return([count_0,count_1,count_2,percentage_0,percentage_1,percentage_2])

topic_ana=pd.DataFrame(columns=['Catgeories','topic 0','topic 1','topic 2',
                                'percentage 0','percentage 1','percentage 2'])    
t=0
#topic by cities
city_list=['Washington, DC','NYC','Chicago','San Francisco']
for myFileName in city_list:
    sample_list=choose_sample_data(dataframe=df,criteria_type='city',criteria=[myFileName]) 
    topic_ana.loc[t,'Catgeories']=myFileName
    topic_ana.loc[t,-6:]=find_percentage(sample_list=sample_list)
    t=t+1
    
#topic by rating
sample_list=choose_sample_data(dataframe=df,criteria_type='rating',criteria=[1,1.5,2,2.5,3])
topic_ana.loc[t,'Catgeories']='low_rating'
topic_ana.loc[t,-6:]=find_percentage(sample_list=sample_list)
t=t+1

sample_list=choose_sample_data(dataframe=df,criteria_type='rating',criteria=[3.5,4])
topic_ana.loc[t,'Catgeories']='mid_rating'
topic_ana.loc[t,-6:]=find_percentage(sample_list=sample_list)
t=t+1

sample_list=choose_sample_data(dataframe=df,criteria_type='rating',criteria=[4.5,5])
topic_ana.loc[t,'Catgeories']='high_rating'
topic_ana.loc[t,-6:]=find_percentage(sample_list=sample_list)
t=t+1

#topic by food type
food_type_list=['Asian','North_American_Fast_Food','Mid_South_America',
                'Euro_Sea_Food','African','Coffee_Dessert','Bar_Club_Smoking',
                'Entertainment_Recreation','Others']
for myFileName in food_type_list:
    sample_list=choose_sample_data(dataframe=df,criteria_type='food_type',criteria=[myFileName])
    topic_ana.loc[t,'Catgeories']=myFileName
    topic_ana.loc[t,-6:]=find_percentage(sample_list=sample_list)
    t=t+1

print(topic_ana)

"""
to test is topic percentage is the same among cities, food type and rating
"""

#among cities
test_city=[]
for i in range(4):
    test_city.append(topic_ana.ix[i,1:4])
chi2_contingency(test_city)

#among rating
test_rating=[]
for i in range(3):
    test_rating.append(topic_ana.ix[4+i,1:4])
chi2_contingency(test_rating)

#among food type
test_food=[]
for i in range(9):
    test_food.append(topic_ana.ix[7+i,1:4])
chi2_contingency(test_food)

"""
Word Cloud
Reference
#https://github.com/amueller/word_cloud/blob/master/examples/simple.py
"""
def wordcloud(sample_list,fig_name):
    word=re.sub(r'[^\w]', ' ', str(sample_list))
    # Generate a word cloud image
    wordcloud = WordCloud().generate(str(word))
    # Display the generated image:
    # the matplotlib way:
    plt.figure(figsize=(50,20),dpi=100)
    plt.imshow(wordcloud)
    plt.axis("off")
    plt.savefig(fig_name+'_word_cloud.jpeg')
    plt.figure()

#and word cloud by cities
city_list=['Washington, DC','NYC','Chicago','San Francisco']
for myFileName in city_list:
    print(myFileName)
    sample_list=choose_sample_data(dataframe=df,criteria_type='city',criteria=[myFileName])
    wordcloud(sample_list=sample_list,fig_name=myFileName)


DC=df.loc[df['city'].isin(['Washington, DC'])]
NYC=df.loc[df['city'].isin(['NYC'])]
CHI=df.loc[df['city'].isin(['Chicago'])]
SF=df.loc[df['city'].isin(['San Francisco'])] 

#word cloud by rating in different cities
for city in [DC,NYC,CHI,SF]:
    city=reindex(city)
    city_name=city.ix[1,'city']
    print(city_name)
    sample_list=choose_sample_data(dataframe=city,criteria_type='rating',criteria=[1,1.5,2,2.5,3])
    wordcloud(sample_list=sample_list,fig_name=city_name+'_low_rating')
    sample_list=choose_sample_data(dataframe=city,criteria_type='rating',criteria=[3.5,4])
    wordcloud(sample_list=sample_list,fig_name=city_name+'_mid_rating')
    sample_list=choose_sample_data(dataframe=city,criteria_type='rating',criteria=[4.5,5])
    wordcloud(sample_list=sample_list,fig_name=city_name+'_high_rating')

#word cloud of categories by food type 
def choose_category_sample_data(dataframe,criteria_type,criteria):
    test_data=dataframe.loc[df[criteria_type].isin(criteria)]
    sample=test_data.ix[:,'categories_list']
    sample_list=sample.tolist()
    return(sample_list)
    
food_type_list=['Asian','North_American_Fast_Food','Mid_South_America',
                'Euro_Sea_Food','African','Coffee_Dessert','Bar_Club_Smoking',
                'Entertainment_Recreation','Others']
for city in [DC,NYC,CHI,SF]:
    city=reindex(city)
    city_name=city.ix[1,'city']  
    print(city_name)
    for myFileName in food_type_list:
        print(myFileName)
        sample_list=choose_category_sample_data(dataframe=city,criteria_type='food_type',criteria=[myFileName])
        wordcloud(sample_list=sample_list,fig_name=city_name+'_'+myFileName)


city_list=['Washington, DC','NYC','Chicago','San Francisco']
for myFileName in city_list:
    print(myFileName)
    sample_list=choose_category_sample_data(dataframe=df,criteria_type='city',criteria=[myFileName])
    wordcloud(sample_list=sample_list,fig_name=myFileName+"categories")

