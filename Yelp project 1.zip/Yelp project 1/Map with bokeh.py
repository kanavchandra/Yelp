import pandas as pd
from bokeh.io import output_file, show
from bokeh.models import (
  GMapPlot, GMapOptions, ColumnDataSource, Circle, DataRange1d, PanTool, WheelZoomTool, BoxSelectTool,HoverTool
)
       
    
def plotting_rating_map(myFileName,location):    
    print(myFileName)
    myData=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/'+myFileName+'_analysis.csv',sep=',',encoding='latin1')

    def choose_test_data(criteria_type,criteria):
        test_data=myData.loc[myData[criteria_type].isin(criteria)]
        return(test_data)
        
    #plot function
    def add_point(test_data,color):    
        source = ColumnDataSource(
            data=dict(
                name=test_data[' name'],
                rating=test_data['rating'],
                lat=test_data['latitude'],
                lon=test_data['longitude'],
                category=test_data['category']
            )
        )
        
        circle = Circle(x="lon", y="lat", size=6, fill_color=color, fill_alpha=0.5, line_color=None)
        plot.add_glyph(source, circle)    
    
  
    #Set Map options
    map_options = GMapOptions(lat=location[0], lng=location[1], map_type="roadmap", zoom=11)
    plot = GMapPlot(
        x_range=DataRange1d(), y_range=DataRange1d(), map_options=map_options, api_key='AIzaSyB5wpG6zVfdEMBkN8LKR89lOrrxV9bPHZo'
    )
    
    plot.add_tools(PanTool(), WheelZoomTool(), BoxSelectTool(),HoverTool(
            tooltips=[
                ("Restaurant", "@name"),
                ("Type of food","@category"),
                ("Rating","@rating"),
                ("(Long,Lat)", "(@lon, @lat)")]))
  
    #add high rating
    test_data=choose_test_data(criteria_type='rating',criteria=[4.5,5])
    add_point(test_data,color="red") 
    #add mid rating    
    test_data=choose_test_data(criteria_type='rating',criteria=[3.5,4])
    add_point(test_data,color="yellow")
    #add low rating    
    test_data=choose_test_data(criteria_type='rating',criteria=[1,1.5,2,2.5,3])
    add_point(test_data,color="black")
    
    output_file(myFileName+"_rating.html")
    show(plot)

def plotting_food_type_map(myFileName,location):    
    print(myFileName)
    myData=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/'+myFileName+'_analysis.csv',sep=',',encoding='latin1')

    def choose_test_data(criteria_type,criteria):
        test_data=myData.loc[myData[criteria_type].isin(criteria)]
        return(test_data)
        
    #plot function
    def add_point(test_data,color):    
        source = ColumnDataSource(
            data=dict(
                name=test_data[' name'],
                rating=test_data['rating'],
                lat=test_data['latitude'],
                lon=test_data['longitude'],
                category=test_data['category']
            )
        )
        
        circle = Circle(x="lon", y="lat", size=6, fill_color=color, fill_alpha=0.5, line_color=None)
        plot.add_glyph(source, circle)    
    
  
    #Set Map options
    map_options = GMapOptions(lat=location[0], lng=location[1], map_type="roadmap", zoom=11)
    plot = GMapPlot(
        x_range=DataRange1d(), y_range=DataRange1d(), map_options=map_options, api_key='AIzaSyB5wpG6zVfdEMBkN8LKR89lOrrxV9bPHZo'
    )
    
    plot.add_tools(PanTool(), WheelZoomTool(), BoxSelectTool(),HoverTool(
            tooltips=[
                ("Restaurant", "@name"),
                ("Type of food","@category"),
                ("Rating","@rating"),
                ("(Long,Lat)", "(@lon, @lat)")]))

    test_data=choose_test_data(criteria_type='food_type',criteria=['Asian'])
    add_point(test_data,color="orange") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['North_American_Fast_Food'])
    add_point(test_data,color="blue") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['Mid_South_America'])
    add_point(test_data,color="purple") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['Euro_Sea_Food'])
    add_point(test_data,color="green") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['African'])
    add_point(test_data,color="grey") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['Coffee_Dessert'])
    add_point(test_data,color="brown") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['Bar_Club_Smoking'])
    add_point(test_data,color="red") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['Entertainment_Recreation'])
    add_point(test_data,color="pink") 
    test_data=choose_test_data(criteria_type='food_type',criteria=['Others'])
    add_point(test_data,color="yellow")     

    output_file(myFileName+"_food_type.html")
    show(plot)
    

    
    
    
Chicago_center=[41.878154,-87.629739]      
NYC_center=[40.830133, -73.983385]  
DC_center=[38.907185, -77.036844]
SF_center=[37.774939, -122.419453]

plotting_rating_map(myFileName='Chicago',location=Chicago_center)    
plotting_rating_map(myFileName='Washington, DC',location=DC_center)  
plotting_rating_map(myFileName='NYC',location=NYC_center)  
plotting_rating_map(myFileName='San Francisco',location=SF_center)  

plotting_food_type_map(myFileName='Chicago',location=Chicago_center)    
plotting_food_type_map(myFileName='Washington, DC',location=DC_center)  
plotting_food_type_map(myFileName='NYC',location=NYC_center)  
plotting_food_type_map(myFileName='San Francisco',location=SF_center)  


































