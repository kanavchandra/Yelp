# -*- coding: utf-8 -*-
"""
Created on Tue Dec  6 21:31:54 2016

@author: Jiahao
"""
import pandas as pd
from scipy.stats import chi2_contingency
from scipy.stats.stats import pearsonr  
food_type_list=['Asian','North_American_Fast_Food','Mid_South_America',
                'Euro_Sea_Food','African','Coffee_Dessert','Bar_Club_Smoking',
                'Entertainment_Recreation','Others']
df=pd.DataFrame(columns=[' name','food_type','rating','zip_code'])
city_list=['Washington, DC','NYC','Chicago','San Francisco']
# Pearson correlation coefficient
for myFileName in city_list:
    print(myFileName)
    data=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/'+myFileName+'_analysis.csv',sep=',',encoding='latin1')
    demographic=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/'+myFileName+'_Demographic.csv',sep=',',encoding='latin1')
    # get rating distribution
    data=data[[' name','food_type','rating','postal_code']] 
    print("rating dist.")
    print(data['rating'].value_counts())
    print("food type dist.")
    print(data['food_type'].value_counts())    
    zip=demographic['zip code'].tolist()
    for i in range(len(demographic)):
        zip_code=demographic.ix[i,0]
        data_sub=data.loc[data['postal_code'].isin([zip_code])]
        counts = data_sub['food_type'].value_counts()
        for food in food_type_list:
            try:
                demographic.loc[i,food+'_percentage']=counts[food]/sum(counts)
            except:
                continue
    demographic=demographic.fillna(0)

    #model black_ratio=b*fast_food
    print("Black vs  Fast food")
    X=demographic.ix[:,7]    
    Y=demographic.ix[:,12]
    print (pearsonr(X.tolist(),Y.tolist()))
    print("Latino vs  South American food")
    X=demographic.ix[:,10]    
    Y=demographic.ix[:,13]
    print (pearsonr(X.tolist(),Y.tolist()))
    print("Asian vs  Asian food")
    X=demographic.ix[:,8]    
    Y=demographic.ix[:,11]
    print (pearsonr(X.tolist(),Y.tolist()))
    print("White vs  Bar")
    X=demographic.ix[:,6]    
    Y=demographic.ix[:,17]
    print (pearsonr(X.tolist(),Y.tolist()))    
    print("White vs  Euro Sea food")
    X=demographic.ix[:,6]    
    Y=demographic.ix[:,14]
    print (pearsonr(X.tolist(),Y.tolist()))      
  


# test rating
test=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/rating_summary.csv',sep=',',encoding='latin1')
test=test.transpose()
#DC=NY=CHI=SF
test_list=[]
for i in range(4):
    test_list.append(test.ix[i+1,:])
print(chi2_contingency(test_list))
#NY=CHI
test_list=[]
test_list.append(test.ix[2,:])
test_list.append(test.ix[3,:])
print(chi2_contingency(test_list))

#test food type
test=pd.read_csv('C:/Users/Jiahao/Dropbox/workspace/project_3/Data/food_type_summary.csv',sep=',',encoding='latin1')
#DC=NY=CHI=SF
test_list=[]
for i in range(4):
    test_list.append(test.ix[i,1:])
print(chi2_contingency(test_list))

#DC=CHI
test_list=[]
test_list.append(test.ix[1,1:])
test_list.append(test.ix[2,1:])
print(chi2_contingency(test_list))







