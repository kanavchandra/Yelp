README
#################################DATA##########################################
All the data we get from project 2 and demographic data from additional data 
source are in the folder Data. 
Additional data source:
https://www.census.gov/en.html
http://www.city-data.com/
#################################Rating Prediction##############################
Run the Python File "rating_prediction.py"
It is the same python file in project 2.
#################################Topic Modeling#################################
Run the Python File "topic modeling.py"
Word cloud pictures are saved and sorted in folder "Visualizations\word cloud"
Attention: I output a lot word cloud pictures in the "word cloud" trunk
Run the piece before "word cloud" first to see the output result.
#################################Statistical test###############################
Run the Python File "stat_test.py"
In the first part, we try to find the correlation coefficient between certain 
demographic ratio and food type ratio. Such as (Asian Ration vs Asian restaurant)
In the second part, we use chi-square test to test whether rating and food type
distribution is the same among different cities.
#################################Visualizations##################################
1. Bokeh
Run the Python File "Map with bokeh.py"
We plot restaurant by labeling them with rating or food type.
The output can be seen in folder "Visualizations\bokeh"
---------------------------------------------------------------------------------
2. Population vs # of restaurant 
We use Excel to plot the relationship between population and number of restaurant.
Excel file is in folder "Visualizations\Analysis of pop vs no. of restaurants"
---------------------------------------------------------------------------------
3. Summary Chart
We also use Excel to generate some pie charts and bar charts in order to 
summarize our basic statistics analysis.
The plot is in folder "Visualizations\summary chart"
---------------------------------------------------------------------------------
4. Tableau
https://github.com/kanavchandra/Yelp
The plot and file are in folder "Visualizations\Tableau"

#######################################End#######################################
Wish you have a fantastic holiday!


           *             ,
                       _/^\_
                      <     >
     *                 /.-.\         *
              *        `/&\`                   *
                      ,@.*;@,
                     /_o.I %_\    *
        *           (`'--:o(_@;
                   /`;--.,__ `')             *
                  ;@`o % O,*`'`&\ 
            *    (`'--)_@ ;o %'()\      *
                 /`;--._`''--._O'@;
                /&*,()~o`;-.,_ `""`)
     *          /`,@ ;+& () o*`;-';\
               (`""--.,_0 +% @' &()\
               /-.,_    ``''--....-'`)  *
          *    /@%;o`:;'--,.__   __.'\
              ;*,&(); @ % &^;~`"`o;@();         *
              /(); o^~; & ().o@*&`;&%O\
        jgs   `"="==""==,,,.,="=="==="`
           __.----.(\-''#####---...___...-----._
         '`         \)_`"""""`
                 .--' ')
               o(  )_-\
                 `"""` `